$(function() {
    $(".share").click(function() {
        $("#shareShow").toggle();
    })
})